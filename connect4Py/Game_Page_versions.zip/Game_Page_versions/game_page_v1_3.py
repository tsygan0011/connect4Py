# Imports
import tkinter as tk
from tkinter.ttk import *

# Global Var
player_list = []
turn = True
turn_list = []
p1 = []
p2 = []


# Functions
def game_build():
    """
    {This function builds the game and initiates
    the game logic for the game in general}
    :return: NONE
    """
    root = tk.Tk()
    root.geometry("400x400")

    f = Frame(root)
    f.pack()
    # Insert Blocks
    alphabet_list = ["a", "b", "c", "d", "e", "f", "g"]
    for x in range(7):
        namer = alphabet_list[x]
        for i in range(6):
            num = i
            val_name = namer + str(num)
            val = val_name
            val_name = tk.Text(
                f,
                width="6",
                height="3",
                fg="gray",
                bg="gray"
            )
            val_name.insert(tk.INSERT, val)
            val_name.grid(row=6 - i, column=x)
            val_name.bindtags((str(val_name), str(root), "all"))
            player_list.append(val_name)
    btn_list = []
    # Insert Buttons
    for v in range(7):
        # namer = alphabet_list[v]
        btn_name = "Btn " + str(v)
        btn = btn_name
        btn = "Btn " + namer
        btn_list.append(tk.Button(
            f,
            text="Drop",
            width="6",
            height="3",
            command=lambda vi=v: drop(vi)
        ))
        btn_list[v].grid(row=7, column=v)
    text_val = ""
    if turn == True:
        text_val = "Red's Turn"
    else:
        text_val = "Yellow's Turn"
    whos_turn = tk.Label(
        text=text_val
    )
    whos_turn.pack()
    turn_list.append(whos_turn)

    root.mainloop()


def drop(button_id):
    """
    {This function reacts to the on click of each "drop" button}
    :param button_id: ID of the button
    :return: Does not return a value
    """
    global turn
    player = 0

    if turn:
        player = 1
    else:
        player = 2

    status, position = validateinput(button_id + 1, player)
    if position == 90:
        print("Too full")
    else:
        cur_pos = int(position) - (button_id + 1) * 10 - 1 + 6 * button_id
        print(cur_pos)
        update_list(cur_pos)


def update_list(subval):
    # calling on Global variable
    global turn
    if turn == False:
            # Colour the block
            # True for player r, False for player y

            # (button_id = column number, player = turn)
        player_list[subval].configure(fg="yellow", bg="yellow")
        player_list[subval].delete("1.0", "end")
        player_list[subval].insert(tk.INSERT, 'y')
        player_list[subval].update()
        turn = True
        turn_list[0].configure(text="Red's Turn")

    else:
        player_list[subval].configure(fg="red", bg="red")
        player_list[subval].delete("1.0", "end")
        player_list[subval].insert(tk.INSERT, 'r')
        player_list[subval].update()
        turn = False
        turn_list[0].configure(text="Yellow's Turn")
    # return True


# Jing Liang codes
# which path is open for bot + how many more needed
# position of the missing pieces
# how many pieces is needed before victory
bot3winconlist = []
bot2wincon = []


def validateinput(userinput, player):
    highestpiece = 0
    msg = ''

    # checks for highest piece
    for x in p1:
        if int(x[0]) == userinput and int(x[1]) > highestpiece:
            highestpiece = int(x[1])
    for x in p2:
        if int(x[0]) == userinput and int(x[1]) > highestpiece:
            highestpiece = int(x[1])

    # checks if the piece can be placed
    try:
        if highestpiece < 6:
            placement = '%s%s' % (userinput, highestpiece + 1)
            msg = 'Piece placed'

            # places piece and add into list
            print("Printing Placement: " + str(placement))
            if player == 1:
                p1.append(placement)
            elif player == 2:
                p2.append(placement)

            decide = nextnum(player)
            print("Printing Decide: " + str(decide))
        else:
            msg = 'Piece cannot be placed, please select another slot'

        return msg, placement
    except UnboundLocalError:
        return msg, 90


def bot3wincon(player, nextpiece, first, second):  # bot check if 3 in a row have win condition
    if player == 1:
        oppopieces = p2
    elif player == 2:
        oppopieces = p1

    # check for 0 1 1 1 0 win condition
    if nextpiece not in oppopieces + bot3winconlist:
        bot3winconlist.append(nextpiece)

    nextpiece = '%s%s' % (int(nextpiece[0]) - (int(first) * 4), int(nextpiece[1]) - (int(second) * 4))
    if nextpiece not in oppopieces + bot3winconlist and 0 < int(nextpiece[0]) < 8 and 0 < int(nextpiece[1]) < 7:
        bot3winconlist.append(nextpiece)


def bot2wincon(player, nextpiece, first, second):  # bot check if 2 in a row has win condition
    if player == 1:
        playerpieces = p1
        oppopieces = p2
    elif player == 2:
        playerpieces = p2
        oppopieces = p1

    # check for 1 1 0 1 win condition
    slot1 = '%s%s' % (int(nextpiece[0]) + int(first), int(nextpiece[1]) + int(second))
    if nextpiece not in oppopieces + bot3winconlist and slot1 in playerpieces:
        bot3winconlist.append(nextpiece)

    slot1 = '%s%s' % (int(nextpiece[0]) - (int(first) * 3), int(nextpiece[1]) - (int(second) * 3))
    slot2 = '%s%s' % (int(nextpiece[0]) - (int(first) * 4), int(nextpiece[1]) - (int(second) * 4))
    if slot1 not in oppopieces + bot3winconlist and slot2 in playerpieces:
        bot3winconlist.append(slot1)


def wincon(pieces, nextpiece, first, second, player):
    winner = False

    # check if player has won
    for i in range(1, 4):
        nextpiece = '%s%s' % (int(nextpiece[0]) + int(first), int(nextpiece[1]) + int(second))
        if nextpiece not in pieces:
            if i == 3:  # check for bot wincon with 3 in a row
                bot3wincon(player, nextpiece, first, second)
            elif i == 2:  # check for bot wincon with 2 in a row
                bot2wincon(player, nextpiece, first, second)
            break

        elif i == 3:
            winner = True

    return winner


def nextnum(player):
    pieces = []
    winner = False
    msg = ''

    if player == 1:
        pieces = p1
    elif player == 2:
        pieces = p2

    for x in pieces:
        if int(x[0]) > 3:  # checks to the left
            winner = wincon(pieces, x, '-1', '0', player)
            if winner:
                break

        if int(x[0]) > 3 and int(x[1]) < 4:  # checks diagonally left
            winner = wincon(pieces, x, '-1', '1', player)
            if winner:
                break

        if int(x[0]) < 5:  # checks to the right
            winner = wincon(pieces, x, '1', '0', player)
            if winner:
                break

        if int(x[0]) < 5 and int(x[1]) < 4:  # checks diagonally right
            winner = wincon(pieces, x, '1', '1', player)
            if winner:
                break

        if int(x[1]) < 4:  # checks upwards
            winner = wincon(pieces, x, '0', '1', player)
            if winner:
                break

    if winner:
        msg = 'Player ' + str(player) + ' wins!!!'
    elif len(p1) + len(p2) == 42:
        msg = 'Its a draw'
    else:
        msg = 'Keep going~'

    # print(msg)
    # print(bot3winconlist)

    return winner
