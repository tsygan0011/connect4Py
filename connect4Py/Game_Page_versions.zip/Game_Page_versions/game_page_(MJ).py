
# Imports
import tkinter as tk
from tkinter.ttk import *
import Bot as bot

# Global Var
player_list= []
turn = True
turn_list = []
p1 = []
p2 = []
colheights = {
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
    6: 0,
    7: 0
}
bot1 = bot.c4_bot(1,p1,p2,2,colheights)

# Functions
def game_build():
    """
    {Description of Function}
    :param para:
    :return:
    """
    root = tk.Tk()
    root.geometry("400x400")



    def grids(event):
        x = f.event_info()
        print(x)
    f = Frame(root)
    f.pack()
    # Insert Blocks
    alphabet_list = ["a","b","c","d","e","f","g"]
    for x in range(7):
        namer = alphabet_list[x]
        for i in range(6):
            num = i
            val_name = namer + str(num)
            val = val_name
            val_name = tk.Text(
                f,
                width = "6",
                height = "3",
                # fg = "gray",
                # bg = "gray"
            )
            val_name.insert(tk.INSERT, val)
            val_name.grid(row= 6-i, column = x)
            val_name.bindtags((str(val_name), str(root), "all"))
            player_list.append(val_name)
    btn_list = []
    # Insert Buttons
    for v in range(7):
        # namer = alphabet_list[v]
        btn_name = "Btn " + str(v)
        btn = btn_name
        btn = "Btn " + namer
        # btn = tk.Button(
        #     f,
        #     text = btn_name,
        #     width = "6",
        #     height = "3",
        #     command = lambda: drop(str(v))
        # )
        # btn.grid(row = 7, column = v)
        btn_list.append(tk.Button(
            f,
            text = btn_name,
            width = "6",
            height = "3",
            command=lambda vi=v: drop(vi)
        ))
        btn_list[v].grid(row = 7, column = v)
    text_val = ""
    if turn == True:
        text_val  = "Red's Turn"
    else:
        text_val = "Yellow's Turn"
    whos_turn = tk.Label(
        text = text_val
    )
    whos_turn.pack()
    turn_list.append(whos_turn)

    # rootbinding
    # root.bind("<Button-1>", grids)
    root.mainloop()

def drop(button_id):
    # grid_location()
    # print(button_id)
    for x in range(0,6):
        subval = button_id*6 + x
        check = player_list[subval].get("1.0", "end-1c")
        # Checking all the values here
        if check_list(check, subval, button_id) == True:
            break
        else:
            continue
    else:
        print("Layer too full")

# def call_list():


def check_list(check, subval, button_id):
    # calling on Global variable
    global turn

    if check == "r" or check == "y":
        # layer filled, proceed next layer
        return False
    else:
        # Empty, can fill
        if turn:
            validateinput(button_id + 1, 1)
        else:
            validateinput(button_id + 1, 2)
        # switch the turn
        if turn == False:
            # Colour the block
            # True for player r, False for player y

            # (button_id = column number, player = turn)
            print(subval)
            player_list[subval].configure(fg="yellow", bg="yellow")
            player_list[subval].delete("1.0", "end")
            player_list[subval].insert(tk.INSERT, 'y')
            player_list[subval].update()
            turn = True
            turn_list[0].configure(text = "Red's Turn")

        else:
            print(subval)
            player_list[subval].configure(fg="red", bg="red")
            player_list[subval].delete("1.0", "end")
            player_list[subval].insert(tk.INSERT, 'r')
            player_list[subval].update()
            turn = False
            turn_list[0].configure(text = "Yellow's Turn")

            if bot1:
                print("this line is called")
                drop(bot1.make_move())
        return True



# Trash codes
# which path is open for bot + how many more needed
# position of the missing pieces
# how many pieces is needed before victory


def validateinput(userinput, player):
    msg = ''

    # checks if the piece can be placed
    if colheights[userinput] < 6:
        # Place piece and increse height for col
        placement = '%s%s' % (userinput, colheights[userinput] + 1)
        colheights[userinput]+=1
        msg = 'Piece placed'

        # places piece and add into list
        print(placement)
        if player == 1:
            p1.append(placement)
        elif player == 2:
            p2.append(placement)

        decide = nextnum(player)
        print(decide)
        if decide:
            global bot1
            bot1 = None
    else:
        msg = 'Piece cannot be placed, please select another slot'

    return msg


def wincon(pieces, nextpiece, horizontal, vertical, player):
    winner = False

    # check if player has won
    for i in range(1, 4):
        nextpiece = '%s%s' % (int(nextpiece[0]) + int(horizontal), int(nextpiece[1]) + int(vertical))
        if nextpiece not in pieces:
            if bot1:
                if i == 3:  # check for bot wincon with 3 in a row
                    bot1.wincon1110(player, nextpiece, horizontal, vertical)
                elif i == 2:  # check for bot wincon with 2 in a row
                    bot1.wincon1101(player, nextpiece, horizontal, vertical)
                break

        elif i == 3:
            winner = True

    return winner


def nextnum(player):
    pieces = []
    winner = False
    msg = ''
    if bot1:
        bot1.bot3winconlist.clear()

    if player == 1:
        pieces = p1
    elif player == 2:
        pieces = p2

    for x in pieces:
        if int(x[0]) > 3:  # checks to the left
            winner = wincon(pieces, x, '-1', '0', player)
            if winner:
                break

        if int(x[0]) > 3 and int(x[1]) < 4:  # checks diagonally left
            winner = wincon(pieces, x, '-1', '1', player)
            if winner:
                break

        if int(x[0]) < 5:  # checks to the right
            winner = wincon(pieces, x, '1', '0', player)
            if winner:
                break

        if int(x[0]) < 5 and int(x[1]) < 4:  # checks diagonally right
            winner = wincon(pieces, x, '1', '1', player)
            if winner:
                break

        if int(x[1]) < 4:  # checks upwards
            winner = wincon(pieces, x, '0', '1', player)
            if winner:
                break

    if winner:
        msg = 'Player ' + str(player) + ' wins!!!'
    elif len(p1) + len(p2) == 42:
        msg = 'Its a draw'
    else:
        msg = 'Keep going~'

    print(msg)
    # print(bot3winconlist)

    return winner
