# Imports
import tkinter as tk
from tkinter.ttk import *

# Global Var
player_list= []
turn = True
turn_list = []
p1 = []
p2 = []


# Functions
def grid_test():
    """
    {Description of Function}
    :param para:
    :return:
    """
    root = tk.Tk()
    root.geometry("400x400")



    def grids(event):
        x = f.event_info()
        print(x)
    f = Frame(root)
    f.pack()
    # Insert Blocks
    alphabet_list = ["a","b","c","d","e","f","g"]
    for x in range(7):
        namer = alphabet_list[x]
        for i in range(6):
            num = i + 1
            val_name = namer + str(num)
            val = val_name
            val_name = tk.Text(
                f,
                width = "6",
                height = "3",
                fg = "gray",
                bg = "gray"
            )
            val_name.insert(tk.INSERT, val)
            val_name.grid(row= i, column = x)
            val_name.bindtags((str(val_name), str(root), "all"))
            player_list.append(val_name)
    btn_list = []
    # Insert Buttons
    for v in range(7):
        # namer = alphabet_list[v]
        btn_name = "Btn " + str(v)
        btn = btn_name
        btn = "Btn " + namer
        # btn = tk.Button(
        #     f,
        #     text = btn_name,
        #     width = "6",
        #     height = "3",
        #     command = lambda: drop(str(v))
        # )
        # btn.grid(row = 7, column = v)
        btn_list.append(tk.Button(
            f,
            text = btn_name,
            width = "6",
            height = "3",
            command=lambda vi=v: drop(vi)
        ))
        btn_list[v].grid(row = 7, column = v)
    text_val = ""
    if turn == True:
        text_val  = "Red's Turn"
    else:
        text_val = "Yellow's Turn"
    whos_turn = tk.Label(
        text = text_val
    )
    whos_turn.pack()
    turn_list.append(whos_turn)

    # rootbinding
    # root.bind("<Button-1>", grids)
    root.mainloop()

def drop(button_id):
    # grid_location()
    # print(button_id)

    if button_id == 0:
        for x in range(0,6):
            subval = 5-x
            check = player_list[subval].get("1.0", "end-1c")
            # Checking all the values here
            if subval == 5: # checking a6
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 4: # checking a5
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 3: # checking a4
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 2: # checking a3
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 1: # checking a2
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 0: # checking a1
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    print("Layer too full")

    elif button_id == 1:
        for x in range(6, 12):
            subval = 17 - x
            check = player_list[subval].get("1.0", "end-1c")
            # Checking all the values here
            if subval == 6:  # checking b6
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 7:  # checking b5
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 8:  # checking b4
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 9:  # checking b3
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 10:  # checking b2
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 11:  # checking b1
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    print("Layer too full")
    elif button_id == 2:
        for x in range(12, 18):
            subval = 29 - x
            check = player_list[subval].get("1.0", "end-1c")
            # Checking all the values here
            if subval == 17:  # checking a6
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 16:  # checking c5
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 15:  # checking c4
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 14:  # checking c3
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 13:  # checking c2
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 12:  # checking c1
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    print("Layer too full")
    elif button_id == 3:
        for x in range(18, 24):
            subval = 41 - x
            check = player_list[subval].get("1.0", "end-1c")
            # Checking all the values here
            if subval == 23:  # checking d6
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 22:  # checking d5
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 21:  # checking d4
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 20:  # checking d3
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 19:  # checking d2
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 18:  # checking d1
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    print("Layer too full")
    elif button_id == 4:
        for x in range(24, 30):
            subval = 53 - x
            check = player_list[subval].get("1.0", "end-1c")
            # Checking all the values here
            if subval == 29:  # checking e6
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 28:  # checking e5
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 27:  # checking e4
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 26:  # checking e3
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 25:  # checking e2
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 24:  # checking e1
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    print("Layer too full")
    elif button_id == 5:
        for x in range(30, 36):
            subval = 65 - x
            check = player_list[subval].get("1.0", "end-1c")
            # Checking all the values here
            if subval == 35:  # checking f6
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 34:  # checking f5
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 33:  # checking f4
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 32:  # checking f3
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 31:  # checking f2
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 30:  # checking f1
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    print("Layer too full")
    elif button_id == 6:
        for x in range(36, 42):
            print("running")
            subval = 77 - x
            check = player_list[subval].get("1.0", "end-1c")
            print(check)
            print(subval)
            # Checking all the values here
            if subval == 41:  # checking g6
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 40:  # checking g5
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 39:  # checking g4
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 38:  # checking g3
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 37:  # checking g2
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    continue
            elif subval == 36:  # checking g1
                if check_list(check, subval, button_id) == True:
                    break
                else:
                    print("Layer too full")

# def call_list():


def check_list(check, subval, button_id):
    # calling on Global variable
    global turn

    if check == "r" or check == "y":
        # layer filled, proceed next layer
        return False
    else:
        # Empty, can fill
        # switch the turn
        if turn == False:
            # Colour the block
            # True for player r, False for player y
            #
            # (button_id = column number, player = turn)
            player_list[subval].configure(fg="yellow", bg="yellow")
            player_list[subval].delete("1.0", "end")
            player_list[subval].insert(tk.INSERT, 'y')
            player_list[subval].update()
            turn = True
            turn_list[0].configure(text = "Red's Turn")

        else:
            print(subval)
            player_list[subval].configure(fg="red", bg="red")
            player_list[subval].delete("1.0", "end")
            player_list[subval].insert(tk.INSERT, 'r')
            player_list[subval].update()
            turn = False
            turn_list[0].configure(text = "Yellow's Turn")
        return True



# Trash codes
# which path is open for bot + how many more needed
# position of the missing pieces
# how many pieces is needed before victory
boardinput = '2'
playerno = 2
p1 = []
p2 = ['43', '42', '41', '11', '21']

bot3winconlist = []
bot2wincon = []


def validateinput(userinput, player):
    highestpiece = 0
    msg = ''

    # checks for highest piece
    for x in p1:
        if x[0] == userinput and int(x[1]) > highestpiece:
            highestpiece = int(x[1])
    for x in p2:
        if x[0] == userinput and int(x[1]) > highestpiece:
            highestpiece = int(x[1])

    # checks if the piece can be placed
    if highestpiece < 6:
        placement = '%s%s' % (userinput, highestpiece + 1)
        msg = 'Piece placed'

        # places piece and add into list
        if player == 1:
            p1.append(placement)
        elif player == 2:
            p2.append(placement)
    else:
        msg = 'Piece cannot be placed, please select another slot'

    return msg


def bot3wincon(player, nextpiece, first, second):  # bot check if 3 in a row have win condition
    if player == 1:
        oppopieces = p2
    elif player == 2:
        oppopieces = p1

    # check for 0 1 1 1 0 win condition
    if nextpiece not in oppopieces + bot3winconlist:
        bot3winconlist.append(nextpiece)

    nextpiece = '%s%s' % (int(nextpiece[0]) - (int(first) * 4), int(nextpiece[1]) - (int(second) * 4))
    if nextpiece not in oppopieces + bot3winconlist and 0 < int(nextpiece[0]) < 8 and 0 < int(nextpiece[1]) < 7:
        bot3winconlist.append(nextpiece)


def bot2wincon(player, nextpiece, first, second):  # bot check if 2 in a row has win condition
    if player == 1:
        playerpieces = p1
        oppopieces = p2
    elif player == 2:
        playerpieces = p2
        oppopieces = p1

    # check for 1 1 0 1 win condition
    slot1 = '%s%s' % (int(nextpiece[0]) + int(first), int(nextpiece[1]) + int(second))
    if nextpiece not in oppopieces + bot3winconlist and slot1 in playerpieces:
        bot3winconlist.append(nextpiece)

    slot1 = '%s%s' % (int(nextpiece[0]) - (int(first) * 3), int(nextpiece[1]) - (int(second) * 3))
    slot2 = '%s%s' % (int(nextpiece[0]) - (int(first) * 4), int(nextpiece[1]) - (int(second) * 4))
    if slot1 not in oppopieces + bot3winconlist and slot2 in playerpieces:
        bot3winconlist.append(slot1)

    print(bot3winconlist)


def wincon(pieces, nextpiece, first, second, player):
    winner = False

    # check if player has won
    for i in range(1, 4):
        nextpiece = '%s%s' % (int(nextpiece[0]) + int(first), int(nextpiece[1]) + int(second))
        if nextpiece not in pieces:
            if i == 3:  # check for bot wincon with 3 in a row
                bot3wincon(player, nextpiece, first, second)
                print('0 1 1 1 0 bot', bot3winconlist)
            elif i == 2:  # check for bot wincon with 2 in a row
                bot2wincon(player, nextpiece, first, second)
            break

        elif i == 3:
            winner = True

    return winner


def nextnum(player):
    pieces = []
    winner = False
    msg = ''

    if player == 1:
        pieces = p1
    elif player == 2:
        pieces = p2

    for x in pieces:
        if int(x[0]) > 3:  # checks to the left
            winner = wincon(pieces, x, '-1', '0', player)
            if winner:
                break

        if int(x[0]) > 3 and int(x[1]) < 4:  # checks diagonally left
            winner = wincon(pieces, x, '-1', '1', player)
            if winner:
                break

        if int(x[0]) < 5:  # checks to the right
            winner = wincon(pieces, x, '1', '0', player)
            if winner:
                break

        if int(x[0]) < 5 and int(x[1]) < 4:  # checks diagonally right
            winner = wincon(pieces, x, '1', '1', player)
            if winner:
                break

        if int(x[1]) < 4:  # checks upwards
            winner = wincon(pieces, x, '0', '1', player)
            if winner:
                break

    if winner:
        msg = 'Player ' + str(player) + ' wins!!!'
    elif len(p1) + len(p2) == 42:
        msg = 'Its a draw'
    else:
        msg = 'meh'

    print(msg)

    return winner


# msg = validateinput(boardinput, playerno)
# print(msg)
deciding = nextnum(playerno)
print(deciding)
